
//Zainab

//access to submitbutton of size input
 var submitbutton=document.getElementById("sizePicker");
// When size is submitted by the user, call makeGrid()
submitbutton.addEventListener("submit", function(event){
 event.preventDefault();
 makeGrid();
 table .innerHTML=" "; });

// after called makeGrid() function
function makeGrid(){
  //  color input
  //  size input
 var colorPicker=document.getElementById("colorPicker");
 var height=document.getElementById("inputHeight").value;
 var width=document.getElementById("inputWidth").value;
// access to table
 var table=document.getElementById("pixelCanvas");
 //creat element for the body of table
 var tableBody = document.createElement("tbody");
// create nested loop to creat the table based on height and width and then append them to the DOM
for (var row=0;row<height;row++){
   var TR = document.createElement("TR");

  for(var cells=0;cells<width;cells++){
   var TD = document.createElement("TD");
   var cellText = document.createTextNode(' ');
   TD.appendChild(cellText);
   TR.appendChild(TD);
   TD.addEventListener("click", function(event){
  event.target.style.background=colorPicker.value;});
}
tableBody.appendChild(TR);
}
  table.appendChild(tableBody);
  document.body.appendChild(table);
}
